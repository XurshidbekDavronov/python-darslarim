#uzbek-transliterator

Transliterate Cyrillic Uzbek text to Latin and vice versa.
https://uz.wikipedia.org/wiki/Vikipediya:O%CA%BBzbek_lotin_alifbosi_qoidalari